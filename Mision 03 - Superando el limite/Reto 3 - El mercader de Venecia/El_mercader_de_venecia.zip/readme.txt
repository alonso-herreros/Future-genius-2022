Allá por la edad media, hubo un acaudalado noble veneciano que buscaba pretendiente para su hija.
La hija decidió que su futuro marido debía ser alguien inteligente, por lo que le impuso a su padre una 
condición; se casaría con el que fuese capaz de resolver el siguiente acertijo:

La hija se hizo con tres cofres, uno de oro, uno de plata, y uno de plomo. Ocultó un retrato suyo en 
uno de ellos e hizo esculpir sobre los cofres las siguientes inscripciones:

Oro: El retrato está en este cofre.

Plata: El retrato no está en este cofre.

Plomo: El retrato no está en el cofre de oro.

La hija les explicó a los pretendientes que, como mucho, una de las tres afirmaciones era verdadera.

¿Cuál de los cofres contenía el retrato?